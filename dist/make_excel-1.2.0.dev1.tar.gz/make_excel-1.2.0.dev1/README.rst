make_excel
=======================

A script to create excel from Python dictionary data.

----

Example usage:

Example usage -> make_excel({'data': [1, 2, 3, 4, 5, 6, 7], 'data1': ['apples', 'oranges'],  'data3': 1}, full_filepath='output_NsURCM')

This will create an excel of name 'output_NsURCM.xls' with the data supplied to it as Python dictionary.